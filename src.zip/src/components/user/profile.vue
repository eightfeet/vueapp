<template>
  <div>
    <h3>user profile</h3>
    <p>{{$route.params.userId}} {{$route.params.something}}</p>
  </div>
</template>
