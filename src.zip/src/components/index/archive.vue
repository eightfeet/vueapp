<template>
  <div>archive with id: {{$route.params.messageId}}</div>
</template>
